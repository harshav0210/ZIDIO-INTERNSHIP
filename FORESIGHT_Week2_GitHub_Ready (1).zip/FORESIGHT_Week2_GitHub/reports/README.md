# Week 2 Reports

Run `python src/run_week2.py` to generate the EDA memo, charts, and seasonal-naive baseline metrics.

Generated numerical results should come from the supplied Week-1 dataset. Do not fabricate or manually edit the metrics.
