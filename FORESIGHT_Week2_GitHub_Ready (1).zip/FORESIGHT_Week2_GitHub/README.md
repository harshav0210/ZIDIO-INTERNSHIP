# Project FORESIGHT — Week 2

## EDA & Seasonal-Naive Baseline

This repository contains the Week 2 implementation for Project FORESIGHT: Demand & Inventory Intelligence.

### Week 2 work

- Exploratory Data Analysis (EDA)
- Demand distribution analysis
- Top-mover analysis
- Zero-demand/dead-stock review
- Seasonality analysis
- Category demand analysis when available
- Weekly demand aggregation
- Seasonal-naive baseline
- WAPE as the primary accuracy metric
- Forecast bias as a secondary diagnostic
- Time-ordered holdout evaluation

## Project structure

```text
FORESIGHT_Week2/
├── data/
│   └── processed/
│       └── analysis_ready.csv       # Your Week-1 cleaned dataset
├── reports/
│   └── README.md
├── src/
│   ├── week2_eda.py
│   ├── seasonal_naive.py
│   └── run_week2.py
├── tools/
│   └── make_demo_data.py            # Optional smoke-test data only
├── .gitignore
├── requirements.txt
├── run_week2.bat
├── run_week2.sh
└── README.md
```

## Input

Copy your Week-1 cleaned dataset to:

```text
data/processed/analysis_ready.csv
```

Required columns:

```text
date
sku_id
units_sold
```

Optional columns:

```text
revenue
category
```

## Installation

```bash
pip install -r requirements.txt
```

## Run complete Week 2 pipeline

```bash
python src/run_week2.py
```

## Run EDA only

```bash
python src/week2_eda.py --input data/processed/analysis_ready.csv
```

## Run baseline only

```bash
python src/seasonal_naive.py --input data/processed/analysis_ready.csv
```

## Generated outputs

EDA:

```text
reports/week2_eda/EDA_MEMO.md
reports/week2_eda/eda_summary.csv
reports/week2_eda/top_10_skus.csv
reports/week2_eda/category_demand.csv
reports/week2_eda/charts/
```

Baseline:

```text
reports/week2_baseline/baseline_metrics.json
reports/week2_baseline/baseline_per_sku.csv
reports/week2_baseline/baseline_predictions.csv
reports/week2_baseline/weekly_demand.csv
```

## Methodology

The seasonal-naive baseline uses the same SKU's demand from the corresponding week in the previous year (52-week lag). The evaluation uses the final 8 weeks as a time-ordered holdout.

WAPE:

```text
WAPE = sum(abs(actual - forecast)) / sum(abs(actual))
```

Bias:

```text
Bias = sum(forecast - actual)
```

No random shuffling is used for the time-series holdout.

## Important

Do not commit confidential/raw client data. Keep raw data outside the repository unless your internship instructions explicitly permit it.

Do not manually invent or edit WAPE results. Run the pipeline on the actual Week-1 cleaned dataset.

## GitHub

After copying your Week-1 `analysis_ready.csv` into the expected location, commit the Week-2 code:

```bash
git add .
git commit -m "Complete Week 2 EDA and seasonal naive baseline"
git push
```
