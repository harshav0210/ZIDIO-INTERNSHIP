#!/bin/sh
python3 -m pip install -r requirements.txt
python3 src/run_week2.py
