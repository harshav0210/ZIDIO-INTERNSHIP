"""
Project FORESIGHT - Week 2 EDA
Runs exploratory analysis on the Week-1 analysis-ready dataset.

Usage:
    python src/week2_eda.py --input data/processed/analysis_ready.csv
"""
from pathlib import Path
import argparse
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"date", "sku_id", "units_sold"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df["units_sold"] = pd.to_numeric(df["units_sold"], errors="coerce").fillna(0)
    df = df.dropna(subset=["date", "sku_id"]).copy()
    return df.sort_values(["date", "sku_id"])


def make_dirs(out: Path):
    out.mkdir(parents=True, exist_ok=True)
    (out / "charts").mkdir(exist_ok=True)


def summarize(df: pd.DataFrame, out: Path):
    total_units = df["units_sold"].sum()
    total_revenue = df["revenue"].sum() if "revenue" in df else np.nan
    active_skus = df["sku_id"].nunique()
    date_min, date_max = df["date"].min(), df["date"].max()

    weekly = (
        df.set_index("date")
          .groupby(pd.Grouper(freq="W-MON"))["units_sold"]
          .sum()
          .reset_index()
    )
    weekly["week_start"] = weekly["date"].dt.to_period("W-SUN").dt.start_time

    sku_totals = df.groupby("sku_id", as_index=False)["units_sold"].sum()
    top10 = sku_totals.sort_values("units_sold", ascending=False).head(10)
    dead = sku_totals[sku_totals["units_sold"] <= 0].sort_values("units_sold")

    summary = pd.DataFrame({
        "metric": [
            "rows", "active_skus", "start_date", "end_date",
            "total_units", "total_revenue", "zero_demand_sku_count"
        ],
        "value": [
            len(df), active_skus, str(date_min.date()), str(date_max.date()),
            round(total_units, 2),
            round(total_revenue, 2) if pd.notna(total_revenue) else "not available",
            len(dead)
        ]
    })
    summary.to_csv(out / "eda_summary.csv", index=False)
    top10.to_csv(out / "top_10_skus.csv", index=False)

    if "category" in df.columns:
        category = (
            df.groupby("category", as_index=False)["units_sold"]
              .sum()
              .sort_values("units_sold", ascending=False)
        )
        category.to_csv(out / "category_demand.csv", index=False)
    else:
        category = None

    # Weekly demand
    plt.figure(figsize=(11, 5))
    plt.plot(weekly["week_start"], weekly["units_sold"])
    plt.title("Weekly Total Demand")
    plt.xlabel("Week")
    plt.ylabel("Units Sold")
    plt.xticks(rotation=30)
    plt.tight_layout()
    plt.savefig(out / "charts/weekly_total_demand.png", dpi=150)
    plt.close()

    # Top movers
    plt.figure(figsize=(10, 5))
    plt.bar(top10["sku_id"].astype(str), top10["units_sold"])
    plt.title("Top 10 SKUs by Units Sold")
    plt.xlabel("SKU")
    plt.ylabel("Units Sold")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(out / "charts/top_10_skus.png", dpi=150)
    plt.close()

    # Monthly seasonality
    monthly = df.assign(month=df["date"].dt.month).groupby("month")["units_sold"].mean()
    plt.figure(figsize=(9, 5))
    plt.plot(monthly.index, monthly.values, marker="o")
    plt.title("Average Daily Demand by Month")
    plt.xlabel("Month")
    plt.ylabel("Average Units Sold")
    plt.xticks(range(1, 13))
    plt.tight_layout()
    plt.savefig(out / "charts/monthly_seasonality.png", dpi=150)
    plt.close()

    if category is not None:
        plt.figure(figsize=(10, 5))
        plt.bar(category["category"].astype(str), category["units_sold"])
        plt.title("Demand by Category")
        plt.xlabel("Category")
        plt.ylabel("Units Sold")
        plt.xticks(rotation=35, ha="right")
        plt.tight_layout()
        plt.savefig(out / "charts/category_demand.png", dpi=150)
        plt.close()

    return summary, top10, dead, weekly, category


def write_memo(df, summary, top10, dead, weekly, category, out: Path):
    lines = [
        "# Project FORESIGHT — Week 2 EDA Insight Memo",
        "",
        "## 1. Scope",
        "This memo covers exploratory analysis for demand distributions, top movers, dead stock, seasonality, and available business drivers.",
        "",
        "## 2. Dataset profile",
        f"- Rows analysed: **{len(df):,}**",
        f"- SKUs: **{df['sku_id'].nunique():,}**",
        f"- Date range: **{df['date'].min().date()} to {df['date'].max().date()}**",
        f"- Total units sold: **{df['units_sold'].sum():,.0f}**",
        "",
        "## 3. Top movers",
        "The following SKUs have the highest total unit demand:",
        "",
        top10.to_markdown(index=False),
        "",
        "## 4. Dead / zero-demand SKUs",
        f"- SKUs with total recorded demand <= 0: **{len(dead)}**",
        "- These should be reviewed for inactive products, missing sales records, or genuine dead stock.",
        "",
        "## 5. Seasonality",
        "The monthly seasonality chart is generated from observed demand. It should be interpreted as descriptive evidence, not proof of causality.",
        "",
        "## 6. Business insights",
        "1. Demand concentration can be identified from the top-SKU table; high-volume SKUs deserve closer forecast and inventory monitoring.",
        "2. Zero-demand SKUs should be checked against product activity before being treated as genuine dead stock.",
        "3. Monthly demand variation provides an initial seasonality signal that will be tested in the forecasting baseline.",
        "",
        "## 7. Data limitations",
        "- EDA reflects only the supplied extract.",
        "- Missing or sparse history can make SKU-level seasonality unreliable.",
        "- Promotion effects should be separated from ordinary seasonality where promotion data is available.",
        "",
        "## 8. Files produced",
        "- `eda_summary.csv`",
        "- `top_10_skus.csv`",
        "- `category_demand.csv` (when category exists)",
        "- charts under `charts/`",
    ]
    (out / "EDA_MEMO.md").write_text("\n".join(lines), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", default="reports/week2_eda")
    args = parser.parse_args()
    out = Path(args.output)
    make_dirs(out)
    df = load_data(args.input)
    summary, top10, dead, weekly, category = summarize(df, out)
    write_memo(df, summary, top10, dead, weekly, category, out)
    print(f"EDA complete. Reports written to: {out.resolve()}")


if __name__ == "__main__":
    main()
