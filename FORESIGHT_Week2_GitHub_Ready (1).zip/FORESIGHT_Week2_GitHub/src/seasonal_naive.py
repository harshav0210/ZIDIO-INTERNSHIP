"""
Project FORESIGHT - Week 2 Seasonal-Naive Baseline

The brief defines the seasonal-naive baseline as predicting demand equal
to the same period last season. For weekly forecasting, this implementation
uses a 52-week seasonal lag when enough history exists.

It also reports WAPE and bias and uses a time-ordered holdout, avoiding
random train/test splitting.
"""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd


def wape(actual, forecast):
    actual = np.asarray(actual, dtype=float)
    forecast = np.asarray(forecast, dtype=float)
    denominator = np.abs(actual).sum()
    return float(np.abs(actual - forecast).sum() / denominator) if denominator else np.nan


def bias(actual, forecast):
    actual = np.asarray(actual, dtype=float)
    forecast = np.asarray(forecast, dtype=float)
    return float((forecast - actual).sum())


def make_weekly(df):
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])
    df["units_sold"] = pd.to_numeric(df["units_sold"], errors="coerce").fillna(0)

    # Aggregate daily sales to Monday-start weeks.
    weekly = (
        df.set_index("date")
          .groupby("sku_id")["units_sold"]
          .resample("W-MON", label="left", closed="left")
          .sum()
          .rename("actual_units")
          .reset_index()
    )
    return weekly.sort_values(["sku_id", "date"])


def evaluate(weekly, holdout_weeks=8, season_length=52):
    results = []
    forecasts = []

    for sku, g in weekly.groupby("sku_id"):
        g = g.sort_values("date").reset_index(drop=True)
        if len(g) <= season_length + holdout_weeks:
            continue

        train = g.iloc[:-holdout_weeks].copy()
        test = g.iloc[-holdout_weeks:].copy()

        # Seasonal naive: same SKU, same week one year earlier.
        history = train.set_index("date")["actual_units"]
        preds = []
        for d in test["date"]:
            prior = d - pd.Timedelta(weeks=season_length)
            preds.append(float(history.get(prior, np.nan)))

        test["forecast_units"] = preds
        test = test.dropna(subset=["forecast_units"])
        if test.empty:
            continue

        results.append({
            "sku_id": sku,
            "test_weeks": len(test),
            "actual_units": test["actual_units"].sum(),
            "forecast_units": test["forecast_units"].sum(),
            "wape": wape(test["actual_units"], test["forecast_units"]),
            "bias_units": bias(test["actual_units"], test["forecast_units"]),
        })
        forecasts.append(test)

    if not results:
        raise ValueError(
            "Not enough weekly history for a 52-week seasonal-naive baseline. "
            "Use a dataset with at least 60 weekly observations per SKU, or "
            "change --season-length only if your business definition supports it."
        )

    per_sku = pd.DataFrame(results)
    all_fc = pd.concat(forecasts, ignore_index=True)
    overall = {
        "method": "seasonal_naive",
        "season_length_weeks": season_length,
        "holdout_weeks": holdout_weeks,
        "overall_wape": wape(all_fc["actual_units"], all_fc["forecast_units"]),
        "overall_bias_units": bias(all_fc["actual_units"], all_fc["forecast_units"]),
        "skus_evaluated": int(per_sku["sku_id"].nunique()),
        "test_rows": int(len(all_fc)),
    }
    return overall, per_sku, all_fc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", default="reports/week2_baseline")
    parser.add_argument("--holdout-weeks", type=int, default=8)
    parser.add_argument("--season-length", type=int, default=52)
    args = parser.parse_args()

    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(args.input)
    if not {"date", "sku_id", "units_sold"}.issubset(df.columns):
        raise ValueError("Input must contain date, sku_id and units_sold.")

    weekly = make_weekly(df)
    weekly.to_csv(out / "weekly_demand.csv", index=False)

    overall, per_sku, forecasts = evaluate(
        weekly,
        holdout_weeks=args.holdout_weeks,
        season_length=args.season_length,
    )
    per_sku.to_csv(out / "baseline_per_sku.csv", index=False)
    forecasts.to_csv(out / "baseline_predictions.csv", index=False)

    (out / "baseline_metrics.json").write_text(
        json.dumps(overall, indent=2), encoding="utf-8"
    )

    print("\nSeasonal-Naive Baseline")
    print("-----------------------")
    print(f"Overall WAPE: {overall['overall_wape']:.4f}")
    print(f"Overall Bias : {overall['overall_bias_units']:.2f} units")
    print(f"SKUs tested : {overall['skus_evaluated']}")
    print(f"Test rows   : {overall['test_rows']}")
    print(f"Reports     : {out.resolve()}")


if __name__ == "__main__":
    main()
