"""Run the complete Week 2 EDA + baseline workflow."""

from pathlib import Path
import argparse
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        default="data/processed/analysis_ready.csv",
        help="Week-1 analysis-ready CSV"
    )
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        raise FileNotFoundError(
            f"Could not find {input_path}. Put your Week-1 cleaned dataset there "
            "or pass --input path/to/analysis_ready.csv"
        )

    commands = [
        [
            sys.executable, "src/week2_eda.py",
            "--input", str(input_path),
            "--output", "reports/week2_eda"
        ],
        [
            sys.executable, "src/seasonal_naive.py",
            "--input", str(input_path),
            "--output", "reports/week2_baseline",
            "--holdout-weeks", "8",
            "--season-length", "52"
        ],
    ]

    for command in commands:
        print("\nRUNNING:", " ".join(command))
        subprocess.run(command, check=True)

    print("\nWEEK 2 COMPLETE")
    print("Open:")
    print("  reports/week2_eda/EDA_MEMO.md")
    print("  reports/week2_baseline/baseline_metrics.json")
    print("  reports/week2_baseline/baseline_predictions.csv")


if __name__ == "__main__":
    main()
