"""Optional smoke-test data generator. Not client data."""
from pathlib import Path
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
dates = pd.date_range("2023-01-02", "2025-12-29", freq="D")
skus = [f"SKU-{i:03d}" for i in range(1, 11)]
rows = []
for i, sku in enumerate(skus, 1):
    base = 8 + i * 2
    for d in dates:
        seasonal = 1 + 0.18 * np.sin(2*np.pi*d.dayofyear/365.25)
        promo = int(d.day in (1, 15))
        units = max(0, rng.poisson(base * seasonal * (1.35 if promo else 1)))
        rows.append((d, sku, units, units * (20 + i), 20 + i, promo))
df = pd.DataFrame(rows, columns=["date","sku_id","units_sold","revenue","unit_price","promo_flag"])
out = Path("data/processed")
out.mkdir(parents=True, exist_ok=True)
df.to_csv(out / "analysis_ready_demo.csv", index=False)
print("Created", out / "analysis_ready_demo.csv")
