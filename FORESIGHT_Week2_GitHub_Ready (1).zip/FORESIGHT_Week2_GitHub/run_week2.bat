@echo off
python -m pip install -r requirements.txt
python src/run_week2.py
pause
