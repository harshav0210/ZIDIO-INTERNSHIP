# Project FORESIGHT — Week 2: EDA & Seasonal-Naive Baseline

This folder implements the Week 2 checkpoint from the Zidio Project FORESIGHT brief.

## Week 2 deliverables

- Exploratory data analysis
- Demand distributions and top movers
- Dead/zero-demand SKU review
- Seasonality analysis
- Category analysis when available
- Weekly demand aggregation
- Seasonal-naive baseline
- WAPE as the primary metric
- Bias as a secondary metric
- Time-ordered holdout evaluation

The engagement brief specifies Week 2 as "EDA & Baseline" and asks for an EDA insight memo plus a working seasonal-naive baseline with a chosen metric.

## Expected Week-1 input

Place your cleaned Week-1 dataset here:

`data/processed/analysis_ready.csv`

Minimum required columns:

- `date`
- `sku_id`
- `units_sold`

Optional columns used when present:

- `revenue`
- `category`

Do not commit large raw client data if it is covered by the project's confidentiality requirements.

## Run

Install dependencies:

```bash
pip install -r requirements.txt
```

Run everything:

```bash
python src/run_week2.py
```

Or run separately:

```bash
python src/week2_eda.py --input data/processed/analysis_ready.csv
python src/seasonal_naive.py --input data/processed/analysis_ready.csv
```

## Output

EDA:

`reports/week2_eda/EDA_MEMO.md`

`reports/week2_eda/eda_summary.csv`

`reports/week2_eda/top_10_skus.csv`

`reports/week2_eda/charts/`

Baseline:

`reports/week2_baseline/baseline_metrics.json`

`reports/week2_baseline/baseline_per_sku.csv`

`reports/week2_baseline/baseline_predictions.csv`

`reports/week2_baseline/weekly_demand.csv`

## Important methodology note

The baseline uses a 52-week seasonal lag because the project asks for weekly demand forecasting and defines the seasonal-naive method as using the same period from the previous season.

The evaluation uses the final 8 weeks as a time-ordered holdout. It does not randomly shuffle time-series observations.

Do not manually enter or invent WAPE results. Run the code on the actual Week-1 cleaned dataset and commit the generated metrics only after verifying them.

## Week 2 checkpoint

The resulting repository evidence supports:

1. EDA insight memo
2. Demand/seasonality charts
3. Feature/data observations needed for Week 3
4. Seasonal-naive baseline
5. WAPE metric
6. Bias diagnostic
7. Reproducible execution from the Week-1 dataset
